#version 330

out vec4 color;

void main()
{
	// café en RGB, igual al usado en la práctica original: 0.478, 0.255, 0.067
	color = vec4(0.478, 0.255, 0.067, 1.0);
}
