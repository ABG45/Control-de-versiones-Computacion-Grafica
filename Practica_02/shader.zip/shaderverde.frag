#version 330

out vec4 color;

void main()
{
	color = vec4(0.0, 0.6, 0.0, 1.0);
}
