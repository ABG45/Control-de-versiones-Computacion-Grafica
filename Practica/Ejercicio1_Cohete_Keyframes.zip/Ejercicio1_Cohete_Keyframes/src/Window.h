#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

//crea la ventana con GLFW y guarda lo que pasa con el teclado y el mouse
class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	bool getpausaAnimaciones() { return pausaAnimaciones; }

	//--- personajes ---
	bool getcaminaHeadcrab() { return caminaHeadcrab; }

	//--- planetas: Xen y planeta 2 ---
	int getzonaPlaneta() { return zonaPlaneta; }
	int getreinicioPlaneta() { return reinicioPlaneta; }

	//--- planeta 3: Verdania ---
	bool getanimaVerdania() { return animaVerdania; }

	//--- pista de carreras y naves ---

	//--- satelites y cuerpos espaciales ---

	//--- plataforma de lanzamiento y cohete ---
	bool getdespegaCohete() { return despegaCohete; }
	//B, R, I y O de la animacion por keyframes; main.cpp compara estos contadores con los que ya atendio
	int getiniciosKeyframes() { return iniciosKeyframes; }
	int getreinicioKeyframes() { return reinicioKeyframes; }
	int getimprimeKeyframes() { return imprimeKeyframes; }
	int getguardaKeyframes() { return guardaKeyframes; }

	//--- estacion espacial y naves ---

	//--- avatar ---
	int getpersonajeAvatar() { return personajeAvatar; }

	//--- camaras y recorridos ---
	int getmodoCamara() { return modoCamara; }
	int getobjetivoCamara() { return objetivoCamara; }
	int getpuntoEspacio() { return puntoEspacio; }
	int getviajeCamara() { return viajeCamara; }
	int getreinicioViaje() { return reinicioViaje; }
	//los recorridos de las camaras 4 y 5 pasan del espacio a un planeta o al reves, por eso cambian la zona desde main.cpp
	void setzonaPlaneta(int zona) { zonaPlaneta = zona; }

	//--- iluminacion: ciclo dia/noche, luminarias y spotlights ---
	bool getlinterna() { return linterna; }
	bool getlucesEscenario() { return lucesEscenario; }
	int getsaltoDiaNoche() { return saltoDiaNoche; }

	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }

	~Window();
private:
	GLFWwindow *mainWindow;
	GLint width, height;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	bool pausaAnimaciones; //P pausa o continua todas las animaciones

	//variables de cada actividad
	//--- personajes ---
	bool caminaHeadcrab; //F prende o apaga la caminata del headcrab cuando se esta en Xen

	//--- planetas: Xen y planeta 2 ---
	int zonaPlaneta; //zona donde esta el usuario, vale 0 en el espacio, 1 en Xen, 2 en el planeta 2 y 3 en Verdania, y la cambian las teclas Z, X, C y V
	int reinicioPlaneta; //cuantas veces se ha presionado la tecla del planeta donde ya se esta, para regresar al punto de llegada
	void IrAPlaneta(int planeta);

	//--- planeta 3: Verdania ---
	bool animaVerdania; //F prende o apaga las animaciones de las plantas cuando se esta en Verdania

	//--- pista de carreras y naves ---

	//--- satelites y cuerpos espaciales ---

	//--- plataforma de lanzamiento y cohete ---
	bool despegaCohete; //F prende o apaga los despegues del cohete cuando se esta en el planeta 2
	int iniciosKeyframes; //cuantas veces se ha presionado la B, que reproduce los keyframes del cohete en el planeta 2
	int reinicioKeyframes; //cuantas veces se ha presionado la R, que regresa el cohete a la plataforma
	int imprimeKeyframes; //cuantas veces se ha presionado la I, que imprime los keyframes en la consola
	int guardaKeyframes; //cuantas veces se ha presionado la O, que guarda los keyframes en un archivo de texto

	//--- estacion espacial y naves ---

	//--- avatar ---
	int personajeAvatar; //personaje que se controla con la camara 2, vale 0 si es Kirby y 1 si es la carnivora, y lo cambia la T

	//--- camaras y recorridos ---
	int modoCamara; //camara que se esta usando, de la 1 a la 5; se cambia con las teclas 1, 2, 3 y 5, y a la 4 se entra con G, H o J
	int objetivoCamara; //nave o vista que sigue la camara; Q le resta 1 y E le suma 1
	int puntoEspacio; //cuantas veces se ha presionado la Z estando en el espacio, para ir al siguiente punto de interes
	int viajeCamara; //planeta a donde va la nave de la camara 4, 0 Xen, 1 Pop Star y 2 Verdania, y lo cambian G, H y J
	int reinicioViaje; //cuantas veces se ha presionado G, H o J, para empezar el viaje desde la estacion

	//--- iluminacion: ciclo dia/noche, luminarias y spotlights ---
	bool linterna; //L prende o apaga la linterna de la camara, empieza apagada
	bool lucesEscenario; //K prende o apaga los spotlights de la zona donde se esta
	int saltoDiaNoche; //cuantas veces se ha presionado la N en un planeta; main.cpp salta a la manana o a la noche cuando cambia

	bool mouseFirstMoved;
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);

};
