#ifndef COMMONVALS
#define COMMONVALS
#include "stb_image.h"

const int MAX_POINT_LIGHTS = 6; //roja, holocron, pinza, luz de la nave y una por cada motor
const int MAX_SPOT_LIGHTS = 6; //linterna, luz fija, faro del rover, 2 faros del avi�n y el reflector de la nave
#endif