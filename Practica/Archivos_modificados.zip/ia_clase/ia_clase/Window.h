#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	GLfloat getmuevex() { return muevex; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	//estado que cambia UNA vez por cada pulsaci�n de tecla
	int getColorFaroAvion() { return colorFaroAvion; } //F: �ndice del color del faro del avi�n (0..5)
	bool getLuzHolocron() { return luzHolocron; }       //H: luz del holocron encendida/apagada
	bool getLuzPinza() { return luzPinza; }             //P: luz de la pinza encendida/apagada
	bool getLucesNave() { return lucesNave; }           //G: luz puntual + reflector de la nave (juntas)
	bool getMotor1() { return motor1; }                 //1: motor 1 (fuego + luz azul)
	bool getMotor2() { return motor2; }                 //2: motor 2 (fuego + luz azul)
	
	~Window();
private: 
	GLFWwindow *mainWindow;
	GLint width, height;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	GLfloat muevex;
	bool mouseFirstMoved;
	int colorFaroAvion;
	bool luzHolocron;
	bool luzPinza;
	bool lucesNave;
	bool motor1;
	bool motor2;
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);

};

