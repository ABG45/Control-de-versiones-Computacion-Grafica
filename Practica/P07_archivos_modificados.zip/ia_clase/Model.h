#pragma once
#include <vector>
#include<string>
#include<assimp/Importer.hpp>
#include<assimp/scene.h>
#include<assimp/postprocess.h>

#include <glm.hpp>
#include "Mesh_tn.h"
#include "Texture.h"

class Model
{
public:
	Model();

	void LoadModel(const std::string& fileName);
	void RenderModel();
	//uniformColor: si se manda la ubicaci�n del uniform "color", los materiales sin textura
	//se dibujan con su color difuso (Kd) del .mtl. Al terminar se regresa el color a blanco.
	void RenderModel(GLint uniformColor);
	void ClearModel();

	~Model();

private:
	void LoadNode(aiNode* node, const aiScene* scene); //assimp
	void LoadMesh(aiMesh* mesh, const aiScene* scene);
	void LoadMaterials(const aiScene* scene);
	std::vector<MeshModel*>MeshList;
	std::vector<Texture*>TextureList;
	std::vector<unsigned int>meshTotex;
	std::vector<glm::vec3>materialColor; //Kd de cada material
	std::vector<bool>materialHasTexture;
};

