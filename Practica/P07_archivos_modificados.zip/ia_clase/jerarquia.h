// jerarquia.h  -  generado a partir de rover_separado.blend
// Sistema de coordenadas: Y arriba, +X = frente del rover, +Z = costado derecho.
// Cada OBJ ya tiene su origen en el pivote, asi que solo hay que trasladarlo
// por "offset" respecto a su padre y rotarlo sobre "eje" entre -45 y +45 grados.
#pragma once

struct ParteRover {
    const char* nombre;
    const char* archivo;
    int         padre;      // indice del padre, -1 si es la raiz
    float       offset[3];  // posicion del pivote respecto al pivote del padre
    char        eje;        // eje local de giro: X, Y, Z  (0 = no gira)
    float       minGrados;
    float       maxGrados;
};

// NOTA: el offset Z de Brazo_Base venia en -12.92717 y dejaba el brazo flotando ~9 unidades
// fuera del cuerpo; se cambio a -1.99394 para que quede sobre la cubierta (z = -2 en el mundo).
static const ParteRover kPartesRover[] = {
    { "Cuerpo", "Cuerpo.obj", -1, {  -0.64337f,   5.13117f,  -0.00606f }, '\0',    0.0f,    0.0f },
    { "Brazo_Base", "Brazo_Base.obj",  0, {   2.34452f,  -0.64952f,  -1.99394f }, 'Y',  -45.0f,   45.0f },
    { "Brazo_Seg1", "Brazo_Seg1.obj",  1, {  -0.20945f,   1.06569f,   0.48648f }, 'Z',  -45.0f,   45.0f },
    { "Brazo_Seg2", "Brazo_Seg2.obj",  2, {   3.44607f,   3.02505f,  -0.66648f }, 'Z',  -45.0f,   45.0f },
    { "Brazo_Pinza", "Brazo_Pinza.obj",  3, {  -2.79462f,   2.01438f,   0.44891f }, 'Z',  -45.0f,   45.0f },
    { "Pata_Del_Der", "Pata_Del_Der.obj",  0, {   5.95990f,  -1.86071f,   3.07606f }, 'Z',  -45.0f,   45.0f },
    { "Rueda_Del_Der", "Rueda_Del_Der.obj",  5, {   0.39585f,  -1.56547f,   0.00000f }, 'Z',  -45.0f,   45.0f },
    { "Pata_Del_Izq", "Pata_Del_Izq.obj",  0, {   5.95990f,  -1.86071f,  -3.06394f }, 'Z',  -45.0f,   45.0f },
    { "Rueda_Del_Izq", "Rueda_Del_Izq.obj",  7, {   0.39340f,  -1.56547f,   0.00000f }, 'Z',  -45.0f,   45.0f },
    { "Pata_Med_Der", "Pata_Med_Der.obj",  0, {  -2.96314f,  -1.70286f,   4.16501f }, 'Z',  -45.0f,   45.0f },
    { "Rueda_Med_Der", "Rueda_Med_Der.obj",  9, {   2.66179f,  -2.01621f,   0.00000f }, 'Z',  -45.0f,   45.0f },
    { "Pata_Med_Izq", "Pata_Med_Izq.obj",  0, {  -2.96314f,  -1.70286f,  -4.15289f }, 'Z',  -45.0f,   45.0f },
    { "Rueda_Med_Izq", "Rueda_Med_Izq.obj", 11, {   2.65932f,  -2.01621f,   0.00000f }, 'Z',  -45.0f,   45.0f },
    { "Pata_Tra_Der", "Pata_Tra_Der.obj",  0, {  -1.82243f,  -1.70286f,   4.16501f }, 'Z',  -45.0f,   45.0f },
    { "Rueda_Tra_Der", "Rueda_Tra_Der.obj", 13, {  -2.66470f,  -2.01621f,   0.00000f }, 'Z',  -45.0f,   45.0f },
    { "Pata_Tra_Izq", "Pata_Tra_Izq.obj",  0, {  -2.03016f,  -1.54586f,  -4.15289f }, 'Z',  -45.0f,   45.0f },
    { "Rueda_Tra_Izq", "Rueda_Tra_Izq.obj", 15, {  -2.43988f,  -2.19956f,   0.00000f }, 'Z',  -45.0f,   45.0f },
};
static const int kNumPartesRover = 17;

